










== Changed Log ==

= 1.1.3 = 
* Improved plugin deactivate if other version is exists

= 1.1.2 = 
* Fixed license key activated by default when installed.

= 1.1.0 = 
* Now it can be implement on normal plugin (without Gutenberg block)

= 1.0.0 =
